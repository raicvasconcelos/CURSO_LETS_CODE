public abstract interface Calculo {

    public abstract double calculo(double primeiroNumero, double segundoNumero);
    
}
